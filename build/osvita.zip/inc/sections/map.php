<section class="v-contact">
	<div class="v-quadro v-quadro_style-1 v-contact__quadro v-contact__quadro_2" data-emergence="hidden"><span class="v-quadro__part v-quadro__part_1"></span><span class="v-quadro__part v-quadro__part_2"></span><span class="v-quadro__part v-quadro__part_3"></span><span class="v-quadro__part v-quadro__part_4"></span><span class="v-quadro__part v-quadro__part_5"></span><span class="v-quadro__part v-quadro__part_6"></span><span class="v-quadro__part v-quadro__part_7"></span><span class="v-quadro__part v-quadro__part_8"></span><span class="v-quadro__part v-quadro__part_9"></span>
	</div>
	<div class="v-contact__map" id="map">
	</div>
	<div class="v-contact__info">
		<p class="v-contact__info-title"><span class="v-color-brand-2">Звоните</span>, <br>приходите в гости
		</p>
		<div class="v-contact__info-part v-contact__info-part_phone"><a class="v-contact__info-link" href="tel: +38 (063) 550 03 20 ">+38 (063) 550 03 20</a><a class="v-contact__info-link" href="tel: +38 (066) 538 27 00 ">+38 (066) 538 27 00</a><a class="v-contact__info-link" href="tel: +38 (066) 538 27 00 ">+38 (066) 538 27 00</a><a class="v-contact__info-link" href="tel: +4 (879) 045 79 50 ">+4 (879) 045 79 50</a>
		</div>
		<div class="v-contact__info-part v-contact__info-part_email"><a class="v-contact__info-link" href="mailto: info@osvitamarket.com ">info@osvitamarket.com</a>
		</div>
	</div>
</section>
<?php include 'inc/sections/map_script.php'; ?>